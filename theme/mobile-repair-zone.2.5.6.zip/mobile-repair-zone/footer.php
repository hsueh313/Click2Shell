<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.WordPress.org/themes/basics/template-files/#template-partials
 *
 * @package Mobile Repair Zone
 */
?>

		<footer id="colophon" class="site-footer border-top">
			<?php if (get_theme_mod('mobile_repair_zone_show_hide_footer', true)) {?>
				<div class="footer-widgets">
				    <div class="container">
				    	<div class="footer-column">
					    	<div class="row">
						        <div class="col-lg-3 col-md-3 col-sm-6 col-12">
						          	<?php if (is_active_sidebar('mobile-repair-zone-footer1')) : ?>
				                        <?php dynamic_sidebar('mobile-repair-zone-footer1'); ?>
				                    <?php else : ?>
				                        <aside id="search" class="widget" role="complementary" aria-label="firstsidebar">
				                            <h5 class="widget-title"><?php esc_html_e( 'About Us', 'mobile-repair-zone' ); ?></h5>
				                            <div class="textwidget">
				                            	<p><?php esc_html_e( 'Nam malesuada nulla nisi, ut faucibus magna congue nec. Ut libero tortor, tempus at auctor in, molestie at nisi. In enim ligula, consequat eu feugiat a.', 'mobile-repair-zone' ); ?></p>
				                            </div>
				                        </aside>
				                    <?php endif; ?>
						        </div>
						        <div class="col-lg-3 col-md-3 col-sm-6 col-12">
						            <?php if (is_active_sidebar('mobile-repair-zone-footer2')) : ?>
				                        <?php dynamic_sidebar('mobile-repair-zone-footer2'); ?>
				                    <?php else : ?>
				                        <aside id="pages" class="widget">
				                            <h5 class="widget-title"><?php esc_html_e( 'Useful Links', 'mobile-repair-zone' ); ?></h5>
				                            <ul class="mt-4">
				                            	<li><?php esc_html_e( 'Home', 'mobile-repair-zone' ); ?></li>
				                            	<li><?php esc_html_e( 'services', 'mobile-repair-zone' ); ?></li>
				                            	<li><?php esc_html_e( 'Reviews', 'mobile-repair-zone' ); ?></li>
				                            	<li><?php esc_html_e( 'About Us', 'mobile-repair-zone' ); ?></li>
				                            </ul>
				                        </aside>
				                    <?php endif; ?>
						        </div>
						        <div class="col-lg-3 col-md-3 col-sm-6 col-12">
						            <?php if (is_active_sidebar('mobile-repair-zone-footer3')) : ?>
				                        <?php dynamic_sidebar('mobile-repair-zone-footer3'); ?>
				                    <?php else : ?>
				                        <aside id="pages" class="widget">
				                            <h5 class="widget-title"><?php esc_html_e( 'Information', 'mobile-repair-zone' ); ?></h5>
				                            <ul class="mt-4">
				                            	<li><?php esc_html_e( 'FAQ', 'mobile-repair-zone' ); ?></li>
				                            	<li><?php esc_html_e( 'Site Maps', 'mobile-repair-zone' ); ?></li>
				                            	<li><?php esc_html_e( 'Privacy Policy', 'mobile-repair-zone' ); ?></li>
				                            	<li><?php esc_html_e( 'Contact Us', 'mobile-repair-zone' ); ?></li>
				                            </ul>
				                        </aside>
				                    <?php endif; ?>
						        </div>
						        <div class="col-lg-3 col-md-3 col-sm-6 col-12">
						            <?php if (is_active_sidebar('mobile-repair-zone-footer4')) : ?>
				                        <?php dynamic_sidebar('mobile-repair-zone-footer4'); ?>
				                    <?php else : ?>
				                        <aside id="pages" class="widget">
				                            <h5 class="widget-title"><?php esc_html_e( 'Get In Touch', 'mobile-repair-zone' ); ?></h5>
				                            <ul class="mt-4">
				                            	<li><?php esc_html_e( 'Via Carlo Montù 78', 'mobile-repair-zone' ); ?><br><?php esc_html_e( '22021 Bellagio CO, Italy', 'mobile-repair-zone' ); ?></li>
				                            	<li><?php esc_html_e( '+11 6254 7855', 'mobile-repair-zone' ); ?></li>
				                            	<li><?php esc_html_e( 'support@example.com', 'mobile-repair-zone' ); ?></li>
				                            </ul>
				                        </aside>
				                    <?php endif; ?>
						        </div>
					      	</div>
				    	</div>
				    </div>
				</div>
		    <?php } ?>
			<?php if (get_theme_mod('mobile_repair_zone_show_hide_copyright', true)) {?>
				<div class="footer_info">
					<div class="container">
				        <div class="site-info">
				            <div class="footer-menu-left">
				            	<?php if(! get_theme_mod('mobile_repair_zone_footer_text_setting') != ''){ ?>
								    <a href="<?php echo esc_url( __( 'https://WordPress.org/', 'mobile-repair-zone' ) ); ?>">
										<?php
										/* translators: %s: CMS name, i.e. WordPress. */
										printf( esc_html__( 'Proudly powered by %s', 'mobile-repair-zone' ), 'WordPress' );
										?>
								    </a>
								    <span class="sep me-1"> | </span>
								    <span>
								       <a target="_blank" href="<?php echo esc_url( 'https://www.themagnifico.net/products/free-mobile-repair-WordPress-theme'); ?>">
								           	<?php
								            	/* translators: 1: Theme name,  */
								            	printf( esc_html__( ' %1$s ', 'mobile-repair-zone' ),'Mobile Repair WordPress Theme ' );
								            ?>
								    	</a>
								    	<?php
							              /* translators: 1: Theme author. */
							              printf( esc_html__( 'by %1$s.', 'mobile-repair-zone' ),'TheMagnifico'  );
							            ?>
								    </span>
								<?php }?>
								<?php echo esc_html(get_theme_mod('mobile_repair_zone_footer_text_setting','')); ?>
				            </div>
					    </div>
					</div>
				</div>
		    <?php } ?>
		  <?php if(get_theme_mod('mobile_repair_zone_scroll_hide',true)){ ?>
			    <a href="#" id="button"><?php esc_html_e('TOP','mobile-repair-zone'); ?></a>
		  <?php } ?>
		</footer>
	</div>
</div>

<?php wp_footer(); ?>

</body>
</html>
