<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.WordPress.org/themes/basics/template-hierarchy/
 *
 * @package Villa Estate Zone
 */

$mobile_repair_zone_post_page_title =  get_theme_mod( 'mobile_repair_zone_post_page_title', 1 );
$mobile_repair_zone_post_page_content =  get_theme_mod( 'mobile_repair_zone_post_page_content', 1 );
?>

<?php
  $mobile_repair_zone_content = apply_filters( 'the_content', get_the_content() );
  $mobile_repair_zone_audio = false;

  // Only get audio from the content if a playlist isn't present.
  if ( false === strpos( $mobile_repair_zone_content, 'wp-playlist-script' ) ) {
    $mobile_repair_zone_audio = get_media_embedded_in_content( $mobile_repair_zone_content, array( 'audio' ) );
  }
?>

  <article id="post-<?php the_ID(); ?>" <?php post_class('article-box'); ?>>
    <?php
      if ( ! is_single() ) {
        // If not a single post, highlight the audio file.
        if ( ! empty( $mobile_repair_zone_audio ) ) {
          foreach ( $mobile_repair_zone_audio as $mobile_repair_zone_audio_html ) {
            echo '<div class="entry-audio">';
              echo $mobile_repair_zone_audio_html;
            echo '</div><!-- .entry-audio -->';
          }
        };
      };
    ?>
    <div class="serv-cont">
      <div class="meta-info-box my-2">
        <span class="entry-author"><?php esc_html_e('BY','mobile-repair-zone'); ?> <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' )) ); ?>"><?php the_author(); ?></a></span>
        <span class="ms-2"><?php echo esc_html(get_the_date()); ?></span>
      </div>
      <div class="post-summery">
        <?php if ($mobile_repair_zone_post_page_title == 1 ) {?>
          <?php the_title('<h3 class="entry-title pb-3"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>');?>
        <?php }?>
        <?php if ($mobile_repair_zone_post_page_content == 1 ) {?>
          <p><?php echo wp_trim_words( get_the_content(), esc_attr(get_theme_mod('mobile_repair_zone_post_page_excerpt_length', 30)) ); ?><?php echo esc_html(get_theme_mod('mobile_repair_zone_post_page_excerpt_suffix','[...]')); ?></p>
        <?php }?>
        <a href="<?php the_permalink(); ?>" class="btn-text"><?php esc_html_e('Read More','mobile-repair-zone'); ?></a>
      </div>
    </div>
  </article>
