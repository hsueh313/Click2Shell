=== Mobile Repair Zone ===
Contributors: TheMagnifico52
Requires at least: 5.0
Tested up to: 7.0
Requires PHP: 7.2
Stable tag: 2.5.6
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Tags: wide-blocks, block-styles, custom-logo, one-column, two-columns, grid-layout, sticky-post, custom-background, custom-colors, custom-header, custom-menu, footer-widgets, featured-images, flexible-header, threaded-comments, theme-options, left-sidebar, right-sidebar, full-width-template, editor-style, rtl-language-support, portfolio, e-commerce, photography

The Mobile Repair Zone theme is a contemporary and highly responsive option ideal for websites that offer various services, such as smartphone repair, computer and laptop repair, printer repair, and tech support.

== Description ==

The Mobile Repair Zone theme is a contemporary and highly responsive option ideal for websites that offer various services, such as smartphone repair, computer and laptop repair, printer repair, and tech support. If you're looking to highlight your flexible services and attract potential clients online, this theme is a fantastic choice. It has undergone rigorous testing to ensure seamless loading on all major browsers, delivering a smooth user experience. Additionally, it’s mobile-friendly, adaptable to any screen size, and supports multiple languages, including RTL layouts. With 100% clean and secure code optimized for speed, your pages will load quickly, ensuring a user-friendly experience. The robust bootstrap framework enhances usability, while social sharing options allow you to connect with your audience across social media, boosting the credibility of your services. Moreover, with a simple one-click installation of demo content, you can quickly set up your grocery store or retail site, and it’s compatible with the WooCommerce plugin for establishing an efficient grocery shop. 

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Mobile Repair Zone in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==

Mobile Repair Zone WordPress Theme, Copyright 2022 TheMagnifico52
Mobile Repair Zone is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Mobile Repair Zone includes support for Infinite Scroll in Jetpack.

== Credits ==

Mobile Repair Zone bundles the following third-party resources:

Bootstrap, Copyright (c) 2011-2024 The Bootstrap Authors
**License:** MIT
Source: https://github.com/twbs/bootstrap

Font Awesome Free 5.6.3 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)

OwlCarousel
 * Copyright 2013-2018 David Deutsch
 * https://github.com/OwlCarousel2/OwlCarousel2
 * https://github.com/OwlCarousel2/OwlCarousel2/blob/develop/LICENSE

Bootstrap
* Bootstrap v5.3.3 (https://getbootstrap.com/)
* Copyright 2011-2024 The Bootstrap Authors
* https://github.com/twbs/bootstrap/releases/download/v5.3.3/bootstrap-5.3.3-dist.zip
* Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)

PSR-4 autoloader
  * Justin Tadlock
  * License: https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
  * Source: https://github.com/WPTRT/autoload

CustomizeSectionButton
  * Justin Tadlock
  * Copyright 2019, Justin Tadlock.
  * License: https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
  * https://github.com/WPTRT/customize-section-button

Webfont-Loader
  * License: https://github.com/WPTT/webfont-loader/blob/master/LICENSE
  * Source: https://github.com/WPTT/webfont-loader

Google Web Fonts
  *	Licenses: Montserrat is the This is the normal family, Licensed under Open Font License
  *	Source: https://github.com/JulietaUla/Montserrat

Stocksnap Images,
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://stocksnap.io/license

  Image, Copyright
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://stocksnap.io/photo/iphone-wood-GXJXPSCKNH

  Image, Copyright
  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://stocksnap.io/photo/laptop-apple-TO31C10FT4

  Image, Copyright
  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://stocksnap.io/photo/business-man-IVZBYWKEFM

  Image, Copyright
  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://stocksnap.io/photo/business-man-7BQNRHB6EX

  Image, Copyright
  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://stocksnap.io/photo/senior-business-UTEZRDTKPP

== Changelog ==


= 0.1

* Initial release.

= 1.1

* Added get-started.
* Updated footer link.

= 1.2

* Added logo settings.
* Updated preloader settings.

= 1.3

* Updated icons setting.
* Updated PHP version.

= 1.4

* Updated sticky header.
* Change file name.
* Updated rtl-support.
* Updated flexible-header.

= 1.5

* Done With Prefixing.
* Escaping URLS.
* Updated PHP version.
* Added require atleast in style.
* Added web-font file.
* Added google font licences.
* Change file name.

= 1.6

* Added general settings.
* Updated description condition.
* Resolve custom header file issue.

= 1.7

* Added pre loader color settings.
* Added phone link.
* Added email link.
* Added some hover effect.

= 1.8

* Updated customizer settings.

= 1.9

* Updated customizer.

= 2.0

* Added urls in customizer.
* Removed top header condition.

= 2.1

* Added footer-widgets.
* Added footer-widgets css.
* Added footer-widgets tag.

= 2.1.1

* Added single post setting.
* Added single post thumbnail on off setting.
* Added single post title on off setting.
* Changed gpl license version.
* Changed gpl license uri.

= 2.1.2

* Added post setting in customizer.
* Added post page title on off setting in customizer.
* Added post page thumbnail on off setting in customizer.
* Added page setting.
* Added single page thumbnail on off setting.
* Added single page title on off setting.

= 2.1.3

* Added tag for rtl css.
* Added rtl css.
* Added scroll to top position setting.
* Added scroll to top position.
* Added custom-option file.
* Added on of footer copyright option in footer text section.
* Added footer columns.
* Done the css for woocommerce pages buttons.
* Added logo resize setting.

= 2.1.4

* Changed redirection function.
* Resolved issue of slider image.

= 2.1.5

* Added single product page sidebar widget.
* Added show/hide single product page sidebar option in customizer.
* Added single product page sidebar layout option in customizer.
* Added shop page sidebar widget.
* Added show/hide shop page sidebar option in customizer.
* Added shop page sidebar layout option in customizer.
* Added slider image opacity option in customizer.

= 2.1.6

* Resolved footer css issue.
* Resolved minor issues of menus.
* Added css for responsive menu.
* Added condition for site tagline.

= 2.1.7

* Added single post page comment title option in customizer.
* Added single post page comment button text option in customizer.
* Added product sale badge position option in customizer.
* Removed redirectional function.
* Added get started notice function.

= 2.1.8

* Changed get started.
* Added single post page tags on off setting in customizer.
* Added post page button on off setting in customizer.

= 2.1.9

* Added rtl css.
* Added hover.

= 2.2

* Added slider height option in customizer.
* Added footer background image option in customizer.

= 2.2.1

* Added post page image border radius option in customizer.
* Added show/ hide woocommerce related products option in customizer.

= 2.2.2

* Added show/ hide post navigation option in customizer.
* Added copyright background color option in customizer.
* Added site title color option in customizer.
* Added site tagline color option in customizer.

= 2.2.3

* Added upsale button in different section in customizer.
* Added free doc link in get started.
* Done shop page product css in responsive media.
* Done searchform and search page css.

= 2.2.4

* Added show/hide footer option in customizer.
* Added product sale badge border radius option in customizer.
* Added scroll to top icon border radius option in customizer.

= 2.2.5

* Added default image for slider
* Added default size for slider in customizer.
* Removed default slider opacity.
* Added css for slider for slider height.
* Added latest bootstrap version.
* Added free doc button in get started.
* Added css in media for container width.
* Added css for submenu.
* Changed preloader bg color.
* Replaced  get start function
* Replaced admin js.
* Done responsive.
* Done homepage css.

= 2.2.6

* Changed the urls for the theme.

= 2.2.7

* Updated archive product template.
* Added default image in archive post.
* Updated lite & pro URLs.
* Updated container width.

= 2.2.8

* Added single post page image border radius option in customizer.
* Added single post page image box shadow option in customizer.
* Added footer widget heading alignment option in customizer.
* Added footer background image position option in customizer.

= 2.2.9

* Added copyright content alignment option in customizer.
* Added show / hide post page content option in customizer.  
* Added footer content alignment option in customizer.
* Added show / hide single post page content option in customizer.

= 2.3

* Added show / hide slider title option in customizer.
* Added show / hide slider content option in customizer.
* Added show / hide slider button option in customizer.
* Added slider button text option in customizer.
* Added POT file.

= 2.3.1

* Added scroll to top background color option in customizer.
* Added scroll to top color option in customizer.
* Added scroll to top font size option in customizer.
* Updated POT file.

= 2.3.2

* Added blog page excerpt length option in customizer.
* Added blog page excerpt suffix option in customizer.
* Added show / hide blog page navigation in customizer.
* Added site width layout option in customizer.
* Added plugin in TGM file.
* Updated POT file.

= 2.3.3

* Added menu font size option in customizer.
* Added menu font weight option in customizer.
* Added menu text transform option in customizer.
* Added slider content layout option in customizer.
* Added slider excerpt length option in customizer.
* Updated POT file.

= 2.3.4

* Added preloader type option in customizer.
* Added preloader color option in customizer.
* Added show/hide slider image opacity option in customizer.
* Updated POT file.

= 2.3.5

* Added blog page pagination type option in customizer.
* Added number of posts per row option in customizer.
* Added blog page sidebar position option in customizer.
* Added single post sidebar position option in customizer.
* Updated POT file.

= 2.3.6

* Resolved textdomain error.
* Added default sidebar.
* Updated default sidebar css.
* Added default footer.
* Change menu css.

= 2.3.7

* Updated woocommerce file.
* Resolved menu issue.
* Added demo impoter.
* Resolved sidebar issue.

= 2.3.8

* Updated getstart.
* Added some getstart file.

= 2.3.9

* Added woocommerce related product column setting.
* Added woocommerce related product per page setting.
* Added woocommerce related product show setting.

= 2.4.0

* Minor fixes and improvements.

= 2.4.1

* Resolved some minor bugs.

= 2.4.2

* Update 404 page.
* Added 404 page setting.
* Update footer.

= 2.4.3

* Added bundle notice.

= 2.4.4

* Made some changes.

= 2.4.5

* Made some changes.

= 2.4.6

* Added post layouts settings option.
* Updated activation notice.
* Updated getstarted.
* Resolved permalink issue.
* Added global color.
* Resolved error for menu pages in demo import.
* Resolved error for blog page pagination type option.
* Resolved error for single post page sidebar.
* Resolved error for single page sidebar.
* Resolved error for shop page sidebar.
* Resolved error for single product page sidebar.

= 2.4.7

* Made some changes.

= 2.4.8

* Made some changes.

= 2.4.9 =

* Fixed malformed HTML closing tags in admin notice (h2, p).
* Fixed missing output escaping: replaced echo wp_get_theme() with esc_html(), _e() with esc_html_e().
* Fixed security: added check_ajax_referer() and current_user_can() to tm_install_and_activate_plugin(), tm_check_plugin_exists(), mobile_repair_zone_demo_importer_ajax_handler() AJAX handlers.
* Fixed security: added nonce verification to mobile_repair_zone_dismissable_notice() and mobile_repair_zone_ajax_notice_handler().
* Fixed security: added nonce verification and capability check to mobile_repair_zone_update_recommended_action_callback() in theme-installation.php.
* Fixed sanitization of $_POST inputs in AJAX handlers using sanitize_key(), sanitize_file_name(), wp_unslash().
* Fixed incorrect esc_attr() usage with multiple arguments in comment date/time display in template-tags.php.
* Fixed orphaned </div> in index.php when no posts are found.
* Fixed deprecated get_page_by_title() replaced with WP_Query via get_posts() per WordPress 6.2 handbook.
* Fixed key name mismatch: nr_actions_recommended -> count_actions_recommended in theme-installation localize script.
* Added recommend_action_nonce to theme-installation localize script.
* Replaced console.log() calls in theme-installation.js with silent error handling.
* Added nonce to recommend-action AJAX call in theme-installation.js.
* Fixed scroll-to-top anchor missing href attribute in footer.php.
* Replaced die() with wp_die() in AJAX handler functions.

= 2.5.0 =
* Description Update.

= 2.5.1 =
* Version Updated.

= 2.5.2 =

* Resolved css error in getstarted, notice and customizer.
* Added content.
* Tested Upto 7.0

= 2.5.3 =

* Changed Theme URI.
= 2.5.4 =
* Responsive Design Improvements.

= 2.5.5 =
* Stability and Performance Enhancements.

= 2.5.6 =
* Enhanced Theme Compatibility.
